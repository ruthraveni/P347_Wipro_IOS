
import SwiftUI

struct LoginView: View {

    @EnvironmentObject var authVM: AuthViewModel

    @State private var faceIDMessage = ""
    @State private var showSignup = false

    var body: some View {

        NavigationStack {

            VStack(spacing: 22) {

                Spacer()

                // App Logo
                Image(systemName: "bolt.circle.fill")
                    .font(.system(size: 85))
                    .foregroundColor(.orange)

                // App Name
                Text("Electricity Meter Log")
                    .font(.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)

                Text("Manage your electricity consumption")
                    .foregroundColor(.gray)

                // Login Fields
                VStack(spacing: 15) {

                    TextField("Username", text: $authVM.username)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("Password", text: $authVM.password)
                        .textFieldStyle(.roundedBorder)

                    // Login Button
                    Button {

                        authVM.login()

                    } label: {

                        Text("Login")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                    }

                    // Face ID Button
                    Button {

                        faceIDMessage = ""
                        authVM.authenticateWithFaceID()

                    } label: {

                        Label(
                            "Login with Face ID",
                            systemImage: "faceid"
                        )
                        .font(.headline)
                        .foregroundColor(.orange)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange.opacity(0.15))
                        .cornerRadius(12)
                    }
                }

                // Login Error
                if !authVM.errorMessage.isEmpty {

                    Text(authVM.errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                        .multilineTextAlignment(.center)
                }

                // Face ID Message
                if !faceIDMessage.isEmpty {

                    Text(faceIDMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                }

                // Signup Navigation
                HStack {

                    Text("New user?")
                        .foregroundColor(.gray)

                    Button("Create Account") {
                        showSignup = true
                    }
                    .fontWeight(.bold)
                }

                Spacer()

                Text("Electricity Management System")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding()
            .navigationDestination(isPresented: $showSignup) {
                SignupView()
                    .environmentObject(authVM)
            }
        }
    }
}
