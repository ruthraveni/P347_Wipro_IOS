
import SwiftUI

struct ReadingListView: View {

    @EnvironmentObject var readingVM: ReadingViewModel

    @AppStorage("lowUsageLimit") private var lowLimit = 100.0
    @AppStorage("normalUsageLimit") private var normalLimit = 300.0

    @State private var searchText = ""
    @State private var selectedFilter = "All"

    private let filters = ["All", "Low", "Normal", "High"]

    private var filteredReadings: [MeterReading] {

        readingVM.readings.filter { reading in

            let matchesSearch =
                searchText.isEmpty ||
                reading.meterName.localizedCaseInsensitiveContains(searchText)

            let usage = reading.unitsConsumed

            let level: String

            if usage < lowLimit {
                level = "Low"
            } else if usage <= normalLimit {
                level = "Normal"
            } else {
                level = "High"
            }

            let matchesFilter =
                selectedFilter == "All" || selectedFilter == level

            return matchesSearch && matchesFilter
        }
    }

    var body: some View {

        VStack {

            Picker("Usage", selection: $selectedFilter) {

                ForEach(filters, id: \.self) { filter in
                    Text(filter)
                        .tag(filter)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            if filteredReadings.isEmpty {

                VStack(spacing: 12) {

                    Image(systemName: "bolt.slash")
                        .font(.system(size: 45))
                        .foregroundColor(.gray)

                    Text("No Readings Found")
                        .font(.headline)

                    Text("Add a new electricity reading.")
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            } else {

                List {

                    ForEach(filteredReadings) { reading in

                        NavigationLink {

                            ReadingDetailView(reading: reading)

                        } label: {

                            VStack(alignment: .leading, spacing: 7) {

                                Text(reading.meterName)
                                    .font(.headline)

                                Text(reading.readingDate, style: .date)
                                    .font(.caption)
                                    .foregroundColor(.gray)

                                Text("Reading: \(reading.currentReading, specifier: "%.2f")")

                                Text("Units: \(reading.unitsConsumed, specifier: "%.2f")")
                                    .font(.subheadline)
                                    .bold()

                                usageLabel(reading.unitsConsumed)
                            }
                            .padding(.vertical, 5)
                        }
                    }
                    .onDelete { indexSet in

                        let selectedReadings = indexSet.map {
                            filteredReadings[$0]
                        }

                        for reading in selectedReadings {
                            readingVM.deleteReading(id: reading.id)
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle("Reading History")
        .searchable(
            text: $searchText,
            prompt: "Search meter name"
        )
        .toolbar {

            ToolbarItem(placement: .navigationBarTrailing) {

                NavigationLink(destination: AddReadingView()) {

                    Image(systemName: "plus")
                }
            }
        }
    }

    private func usageLabel(_ units: Double) -> some View {

        let level: String

        if units < lowLimit {
            level = "Low"
        } else if units <= normalLimit {
            level = "Normal"
        } else {
            level = "High"
        }

        return Text("\(level) Usage")
            .font(.caption)
            .bold()
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(
                level == "Low" ? Color.green.opacity(0.15) :
                level == "Normal" ? Color.orange.opacity(0.15) :
                Color.red.opacity(0.15)
            )
            .foregroundColor(
                level == "Low" ? .green :
                level == "Normal" ? .orange : .red
            )
            .cornerRadius(8)
    }
}
