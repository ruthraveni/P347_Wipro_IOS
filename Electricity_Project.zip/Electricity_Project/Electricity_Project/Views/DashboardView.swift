

import SwiftUI

struct DashboardView: View {

    @EnvironmentObject var readingVM: ReadingViewModel

    @StateObject private var dashboardVM = DashboardViewModel()

    var body: some View {

        ScrollView {

            VStack(spacing: 20) {

                Text("Electricity Dashboard")
                    .font(.largeTitle)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)

                dashboardCard(
                    title: "Total Readings",
                    value: "\(dashboardVM.totalReadings)",
                    icon: "list.number",
                    color: .blue
                )

                dashboardCard(
                    title: "Units This Month",
                    value: String(format: "%.2f", dashboardVM.monthlyUnits),
                    icon: "bolt.fill",
                    color: .orange
                )

                dashboardCard(
                    title: "Estimated Bill",
                    value: String(format: "₹%.2f", dashboardVM.estimatedBill),
                    icon: "indianrupeesign.circle",
                    color: .green
                )

                dashboardCard(
                    title: "Highest Usage Month",
                    value: dashboardVM.highestUsageMonth,
                    icon: "chart.bar.fill",
                    color: .purple
                )

                NavigationLink(destination: AddReadingView()) {

                    Label("Add New Reading", systemImage: "plus.circle.fill")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(12)
                }

                NavigationLink(destination: ReadingListView()) {

                    Label("View All Readings", systemImage: "list.bullet")
                        .font(.headline)
                        .foregroundColor(.blue)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(12)
                }
            }
            .padding()
        }
        .navigationTitle("Dashboard")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            dashboardVM.updateDashboard(
                readings: readingVM.readings
            )
        }
    }

    private func dashboardCard(
        title: String,
        value: String,
        icon: String,
        color: Color
    ) -> some View {

        HStack {

            Image(systemName: icon)
                .font(.system(size: 30))
                .foregroundColor(color)

            VStack(alignment: .leading, spacing: 5) {

                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.gray)

                Text(value)
                    .font(.title2)
                    .bold()
                    .minimumScaleFactor(0.7)
                    .lineLimit(1)
            }

            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(15)
    }
}
