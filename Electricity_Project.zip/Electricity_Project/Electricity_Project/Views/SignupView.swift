
import SwiftUI

struct SignupView: View {

    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var successMessage = ""

    var body: some View {

        ZStack {

            Color(.systemGroupedBackground)
                .ignoresSafeArea()

            ScrollView {

                VStack(spacing: 22) {

                    Image(systemName: "person.crop.circle.badge.plus")
                        .font(.system(size: 65))
                        .foregroundColor(.green)

                    Text("Create Account")
                        .font(.largeTitle.bold())

                    Text("Register to manage your electricity readings")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)

                    VStack(spacing: 15) {

                        TextField("Full Name", text: $authVM.fullName)
                            .textContentType(.name)
                            .signupFieldStyle()

                        TextField("Email Address", text: $authVM.email)
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .signupFieldStyle()

                        TextField("Username", text: $authVM.username)
                            .textInputAutocapitalization(.never)
                            .signupFieldStyle()

                        SecureField("Password", text: $authVM.password)
                            .signupFieldStyle()

                        SecureField(
                            "Confirm Password",
                            text: $authVM.confirmPassword
                        )
                        .signupFieldStyle()
                    }

                    if !authVM.errorMessage.isEmpty {

                        Text(authVM.errorMessage)
                            .foregroundColor(.red)
                            .font(.caption)
                    }

                    Button {

                        if authVM.signup() {
                            successMessage = "Account created successfully!"
                        }

                    } label: {

                        Text("Sign Up")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(12)
                    }

                    if !successMessage.isEmpty {

                        Text(successMessage)
                            .foregroundColor(.green)
                    }

                    Button("Back to Login") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
                .padding(25)
            }
        }
        .navigationTitle("Sign Up")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: successMessage) { _, newValue in

            if !newValue.isEmpty {
                dismiss()
            }
        }
    }
}

extension View {

    func signupFieldStyle() -> some View {

        self
            .padding()
            .background(Color(.secondarySystemGroupedBackground))
            .cornerRadius(12)
    }
}
