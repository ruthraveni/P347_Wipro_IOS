

import SwiftUI

struct EditReadingView: View {

    @EnvironmentObject var readingVM: ReadingViewModel

    @Environment(\.dismiss) private var dismiss

    @State private var editedReading: MeterReading

    @State private var showAlert = false
    @State private var alertMessage = ""

    init(reading: MeterReading) {

        _editedReading = State(initialValue: reading)
    }

    var body: some View {

        Form {

            Section("Edit Reading") {

                DatePicker(
                    "Reading Date",
                    selection: $editedReading.readingDate,
                    displayedComponents: .date
                )

                TextField(
                    "Meter Name",
                    text: $editedReading.meterName
                )

                TextField(
                    "Current Reading",
                    value: $editedReading.currentReading,
                    format: .number
                )
                .keyboardType(.decimalPad)

                TextField(
                    "Rate Per Unit",
                    value: $editedReading.ratePerUnit,
                    format: .number
                )
                .keyboardType(.decimalPad)

                TextField(
                    "Notes",
                    text: $editedReading.notes,
                    axis: .vertical
                )
            }

            Section("Calculated Details") {

                Text(
                    "Previous Reading: \(editedReading.previousReading, specifier: "%.2f")"
                )

                Text(
                    "Units Consumed: \(editedReading.unitsConsumed, specifier: "%.2f")"
                )

                Text(
                    "Estimated Cost: ₹\(editedReading.estimatedCost, specifier: "%.2f")"
                )
            }

            Section {

                Button("Update Reading") {

                    updateReading()
                }
                .frame(maxWidth: .infinity)
                .foregroundColor(.white)
                .listRowBackground(Color.blue)
            }
        }
        .navigationTitle("Edit Reading")
        .alert("Reading", isPresented: $showAlert) {

            Button("OK") {

                if alertMessage == "Reading updated successfully" {
                    dismiss()
                }
            }

        } message: {

            Text(alertMessage)
        }
    }

    private func updateReading() {

        guard !editedReading.meterName
            .trimmingCharacters(in: .whitespaces)
            .isEmpty else {

            alertMessage = "Please enter meter name"
            showAlert = true
            return
        }

        guard editedReading.currentReading >= 0,
              editedReading.ratePerUnit >= 0,
              editedReading.currentReading >= editedReading.previousReading else {

            alertMessage = "Please enter valid reading values"
            showAlert = true
            return
        }

        if readingVM.updateReading(editedReading) {

            alertMessage = "Reading updated successfully"

        } else {

            alertMessage = "Unable to update reading"
        }

        showAlert = true
    }
}
