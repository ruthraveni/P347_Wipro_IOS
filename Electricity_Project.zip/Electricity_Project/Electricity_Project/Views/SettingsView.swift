
import SwiftUI

struct SettingsView: View {

    @EnvironmentObject var authVM: AuthViewModel
    @EnvironmentObject var readingVM: ReadingViewModel

    @AppStorage("lowUsageLimit") private var lowLimit = 100.0
    @AppStorage("normalUsageLimit") private var normalLimit = 300.0

    @State private var showDeleteAlert = false

    var body: some View {

        Form {

            Section("Usage Level Settings") {

                Stepper(
                    "Low Usage: \(Int(lowLimit)) units",
                    value: $lowLimit,
                    in: 1...1000,
                    step: 10
                )

                Stepper(
                    "Normal Usage Limit: \(Int(normalLimit)) units",
                    value: $normalLimit,
                    in: 10...2000,
                    step: 10
                )

                Text("Below Low limit = Low; up to Normal limit = Normal; above Normal limit = High.")
                    .font(.caption)
                    .foregroundColor(.gray)
            }

            Section("Data Management") {

                Button(role: .destructive) {

                    showDeleteAlert = true

                } label: {

                    Label("Delete All Readings", systemImage: "trash")
                }
            }

            Section("Account") {

                Button(role: .destructive) {

                    authVM.logout()

                } label: {

                    Label("Logout", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }

            Section("About") {

                Text("Electricity Meter Log")
                    .font(.headline)

                Text("Version 1.0")
                    .foregroundColor(.gray)
            }
        }
        .navigationTitle("Settings")
        .onChange(of: lowLimit) {
            if normalLimit <= lowLimit {
                normalLimit = lowLimit + 10
            }
        }
        .onChange(of: normalLimit) {
            if normalLimit <= lowLimit {
                lowLimit = max(1, normalLimit - 10)
            }
        }
        .alert("Delete All Readings?", isPresented: $showDeleteAlert) {

            Button("Cancel", role: .cancel) {}

            Button("Delete All", role: .destructive) {

                readingVM.deleteAllReadings()
            }

        } message: {

            Text("This will permanently delete all saved readings.")
        }
    }
}

