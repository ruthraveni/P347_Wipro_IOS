
import SwiftUI

struct ReadingDetailView: View {

    @EnvironmentObject var readingVM: ReadingViewModel

    @Environment(\.dismiss) private var dismiss

    let reading: MeterReading

    @State private var showDeleteAlert = false

    var body: some View {

        Form {

            Section("Meter Information") {

                detailRow("Meter Name", reading.meterName)

                detailRow(
                    "Reading Date",
                    reading.readingDate.formatted(date: .long, time: .omitted)
                )
            }

            Section("Reading Values") {

                detailRow(
                    "Previous Reading",
                    String(format: "%.2f", reading.previousReading)
                )

                detailRow(
                    "Current Reading",
                    String(format: "%.2f", reading.currentReading)
                )

                detailRow(
                    "Units Consumed",
                    String(format: "%.2f units", reading.unitsConsumed)
                )
            }

            Section("Bill Details") {

                detailRow(
                    "Rate Per Unit",
                    String(format: "₹%.2f", reading.ratePerUnit)
                )

                detailRow(
                    "Estimated Cost",
                    String(format: "₹%.2f", reading.estimatedCost)
                )
            }

            Section("Notes") {

                Text(
                    reading.notes.isEmpty
                    ? "No notes available"
                    : reading.notes
                )
            }

            Section {

                NavigationLink(
                    destination: EditReadingView(reading: reading)
                ) {

                    Label("Edit Reading", systemImage: "pencil")
                        .foregroundColor(.blue)
                }

                Button(role: .destructive) {

                    showDeleteAlert = true

                } label: {

                    Label("Delete Reading", systemImage: "trash")
                }
            }
        }
        .navigationTitle("Reading Details")
        .alert("Delete Reading?", isPresented: $showDeleteAlert) {

            Button("Cancel", role: .cancel) {}

            Button("Delete", role: .destructive) {

                readingVM.deleteReading(id: reading.id)
                dismiss()
            }

        } message: {

            Text("Are you sure you want to delete this reading?")
        }
    }

    private func detailRow(
        _ title: String,
        _ value: String
    ) -> some View {

        HStack {

            Text(title)

            Spacer()

            Text(value)
                .foregroundColor(.secondary)
        }
    }
}

