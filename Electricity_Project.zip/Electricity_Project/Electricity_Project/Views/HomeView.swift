
import SwiftUI

struct HomeView: View {

    var body: some View {

        NavigationStack {

            ZStack {

                LinearGradient(
                    colors: [
                        Color(red: 0.04, green: 0.20, blue: 0.17),
                        Color(red: 0.08, green: 0.38, blue: 0.30)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 25) {

                    Spacer()

                    Image(systemName: "bolt.circle.fill")
                        .font(.system(size: 100))
                        .foregroundColor(.yellow)

                    Text("Electricity Meter Log")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)

                    Text("Track • Monitor • Save Energy")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.8))

                    Text("Welcome Home!")
                        .font(.title2.bold())
                        .foregroundColor(.white)
                        .padding(.top, 25)

                    Text("Manage your electricity consumption easily.")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.75))
                        .multilineTextAlignment(.center)

                    Spacer()

                    NavigationLink {
                        LoginView()
                    } label: {

                        HStack {
                            Image(systemName: "person.fill")
                            Text("Login")
                        }
                        .font(.headline)
                        .foregroundColor(.green)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.white)
                        .cornerRadius(14)
                    }

                    NavigationLink {
                        SignupView()
                    } label: {

                        HStack {
                            Image(systemName: "person.badge.plus")
                            Text("Create New Account")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(14)
                    }

                    Spacer()

                    Text("Electricity Management System")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                }
                .padding(25)
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

