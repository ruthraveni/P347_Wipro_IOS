
import SwiftUI

struct AddReadingView: View {

    @EnvironmentObject var readingVM: ReadingViewModel

    @Environment(\.dismiss) private var dismiss

    @State private var readingDate = Date()
    @State private var meterName = "Home"
    @State private var currentReading = ""
    @State private var ratePerUnit = "5"
    @State private var notes = ""

    @State private var showAlert = false
    @State private var alertMessage = ""

    private var previousReading: Double {

        readingVM.readings
            .filter {
                $0.meterName.localizedCaseInsensitiveCompare(meterName) == .orderedSame &&
                $0.readingDate <= readingDate
            }
            .max(by: {
                $0.readingDate < $1.readingDate
            })?
            .currentReading ?? 0
    }

    private var units: Double {

        guard let current = Double(currentReading) else {
            return 0
        }

        return current - previousReading
    }

    var body: some View {

        Form {

            Section("Reading Information") {

                DatePicker(
                    "Reading Date",
                    selection: $readingDate,
                    displayedComponents: .date
                )

                TextField("Meter / Connection Name", text: $meterName)

                Text("Previous Reading: \(previousReading, specifier: "%.2f")")
                    .foregroundColor(.gray)

                TextField("Current Reading", text: $currentReading)
                    .keyboardType(.decimalPad)

                TextField("Rate Per Unit (₹)", text: $ratePerUnit)
                    .keyboardType(.decimalPad)
            }

            Section("Consumption Details") {

                Text("Units Consumed: \(units, specifier: "%.2f")")

                Text(
                    "Estimated Bill: ₹\(max(0, units) * (Double(ratePerUnit) ?? 0), specifier: "%.2f")"
                )
                .bold()
            }

            Section("Notes") {

                TextField("Enter Notes", text: $notes, axis: .vertical)
                    .lineLimit(3...5)
            }

            Section {

                Button("Save Reading") {
                    saveReading()
                }
                .frame(maxWidth: .infinity)
                .foregroundColor(.white)
                .listRowBackground(Color.blue)
            }
        }
        .navigationTitle("Add Reading")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Reading", isPresented: $showAlert) {

            Button("OK") {
                if alertMessage == "Reading saved successfully" {
                    dismiss()
                }
            }

        } message: {
            Text(alertMessage)
        }
    }

    private func saveReading() {

        guard
            let current = Double(currentReading),
            let rate = Double(ratePerUnit),
            !meterName.trimmingCharacters(in: .whitespaces).isEmpty
        else {
            alertMessage = "Please enter valid reading details"
            showAlert = true
            return
        }

        guard current >= 0, rate >= 0 else {
            alertMessage = "Values cannot be negative"
            showAlert = true
            return
        }

        guard current > previousReading else {
            alertMessage = "Current reading must be greater than previous reading"
            showAlert = true
            return
        }

        let reading = MeterReading(
            readingDate: readingDate,
            currentReading: current,
            previousReading: previousReading,
            meterName: meterName,
            ratePerUnit: rate,
            notes: notes
        )

        if readingVM.addReading(reading) {

            alertMessage = "Reading saved successfully"

        } else {

            alertMessage = "Unable to save reading"
        }

        showAlert = true
    }
}

