
import SwiftUI

struct RootView: View {

    @StateObject private var authVM = AuthViewModel()
    @StateObject private var readingVM = ReadingViewModel()

    var body: some View {

        Group {

            if authVM.isAuthenticated {
                MainTabView()
            } else {
                HomeView()
            }
        }
        .environmentObject(authVM)
        .environmentObject(readingVM)
        .onChange(of: authVM.currentUsername) { _, newUsername in

            if newUsername.isEmpty {
                readingVM.switchUser(to: "")
            } else {
                readingVM.switchUser(to: newUsername)
            }
        }
    }
}

struct MainTabView: View {

    var body: some View {

        TabView {

            NavigationStack {
                DashboardView()
            }
            .tabItem {
                Label("Dashboard", systemImage: "house.fill")
            }

            NavigationStack {
                ReadingListView()
            }
            .tabItem {
                Label("Readings", systemImage: "list.bullet")
            }

            NavigationStack {
                SettingsView()
            }
            .tabItem {
                Label("Settings", systemImage: "gearshape.fill")
            }
        }
    }
}
