
import Foundation
import Combine

class ReadingViewModel: ObservableObject {

    @Published var readings: [MeterReading] = []

    private let storage = StorageService.shared
    private var activeUsername = ""

    init() {
        readings = []
    }


    func switchUser(to username: String) {

        activeUsername = username.lowercased()
        loadReadings()
    }

  
    func loadReadings() {

        guard !activeUsername.isEmpty else {
            readings = []
            return
        }

        readings = storage.loadReadings(for: activeUsername)
        recalculatePreviousReadings()
    }

  
    func addReading(_ reading: MeterReading) -> Bool {

        guard !activeUsername.isEmpty,
              reading.currentReading >= 0,
              reading.ratePerUnit >= 0,
              !reading.meterName.isEmpty else {
            return false
        }

        readings.append(reading)
        recalculatePreviousReadings()
        saveReadings()

        return true
    }


    func updateReading(_ updatedReading: MeterReading) -> Bool {

        guard !activeUsername.isEmpty,
              let index = readings.firstIndex(where: {
                  $0.id == updatedReading.id
              }) else {
            return false
        }

        guard updatedReading.currentReading >= 0,
              updatedReading.ratePerUnit >= 0,
              !updatedReading.meterName.isEmpty else {
            return false
        }

        readings[index] = updatedReading
        recalculatePreviousReadings()

        let invalidReading = readings.contains {
            $0.currentReading < $0.previousReading
        }

        if invalidReading {
            loadReadings()
            return false
        }

        saveReadings()
        return true
    }

    // Delete reading
    func deleteReading(id: UUID) {

        readings.removeAll {
            $0.id == id
        }

        recalculatePreviousReadings()
        saveReadings()
    }

    // Delete all readings for current user
    func deleteAllReadings() {

        readings.removeAll()

        guard !activeUsername.isEmpty else { return }

        storage.deleteAllReadings(for: activeUsername)
    }

    // Recalculate previous readings for each meter
    private func recalculatePreviousReadings() {

        let grouped = Dictionary(
            grouping: readings,
            by: { $0.meterName.lowercased() }
        )

        var previousValues: [UUID: Double] = [:]

        for group in grouped.values {

            let sortedGroup = group.sorted {
                $0.readingDate < $1.readingDate
            }

            var previousValue = 0.0

            for reading in sortedGroup {

                previousValues[reading.id] = previousValue
                previousValue = reading.currentReading
            }
        }

        readings = readings.map { reading in

            var updated = reading

            updated.previousReading =
                previousValues[reading.id] ?? 0

            return updated
        }

        readings.sort {
            $0.readingDate > $1.readingDate
        }
    }

    // Get selected reading
    func getReading(id: UUID) -> MeterReading? {

        return readings.first {
            $0.id == id
        }
    }

    // Save readings for current user
    private func saveReadings() {

        guard !activeUsername.isEmpty else { return }

        storage.saveReadings(
            readings,
            for: activeUsername
        )
    }
}
