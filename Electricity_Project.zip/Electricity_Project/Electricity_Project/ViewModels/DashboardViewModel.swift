
import Foundation
import Combine

class DashboardViewModel: ObservableObject {

    @Published var totalReadings: Int = 0

    @Published var monthlyUnits: Double = 0

    @Published var estimatedBill: Double = 0

    @Published var highestUsageMonth: String = "No Data"

    // Update dashboard using meter readings
    func updateDashboard(readings: [MeterReading]) {

        totalReadings = readings.count

        let calendar = Calendar.current
        let currentDate = Date()

        // Filter current month readings
        let currentMonthReadings = readings.filter {
            calendar.isDate(
                $0.readingDate,
                equalTo: currentDate,
                toGranularity: .month
            )
        }

        // Calculate monthly units
        monthlyUnits = currentMonthReadings.reduce(0) {
            $0 + $1.unitsConsumed
        }

        // Calculate estimated bill
        estimatedBill = currentMonthReadings.reduce(0) {
            $0 + $1.estimatedCost
        }

        // Group readings by month
        var monthlyUsage: [Date: Double] = [:]

        for reading in readings {

            let components = calendar.dateComponents(
                [.year, .month],
                from: reading.readingDate
            )

            if let monthDate = calendar.date(from: components) {

                monthlyUsage[monthDate, default: 0] += reading.unitsConsumed
            }
        }

        // Find highest usage month
        if let highestMonth = monthlyUsage.max(by: {
            $0.value < $1.value
        }) {

            let formatter = DateFormatter()
            formatter.dateFormat = "MMMM yyyy"

            highestUsageMonth = formatter.string(
                from: highestMonth.key
            )

        } else {

            highestUsageMonth = "No Data"
        }
    }
}

