
import Foundation
import Combine
import CryptoKit

class AuthViewModel: ObservableObject {

    @Published var username = ""
    @Published var password = ""
    @Published var isAuthenticated = false
    @Published var errorMessage = ""

    @Published var fullName = ""
    @Published var email = ""
    @Published var confirmPassword = ""

    @Published var currentUsername = ""

    private let defaults = UserDefaults.standard
    private let usersKey = "RegisteredUsers"

    // MARK: - User Storage

    private var users: [String: [String: String]] {

        get {
            defaults.dictionary(forKey: usersKey)
                as? [String: [String: String]] ?? [:]
        }

        set {
            defaults.set(newValue, forKey: usersKey)
        }
    }

    // MARK: - Password Hashing

    private func hashPassword(_ password: String) -> String {

        let data = Data(password.utf8)
        let hash = SHA256.hash(data: data)

        return hash.map {
            String(format: "%02x", $0)
        }.joined()
    }

    // MARK: - Signup

    func signup() -> Bool {

        let name = fullName.trimmingCharacters(in: .whitespaces)
        let user = username.trimmingCharacters(in: .whitespaces)
        let mail = email.trimmingCharacters(in: .whitespaces)

        if name.isEmpty || user.isEmpty ||
            mail.isEmpty || password.isEmpty ||
            confirmPassword.isEmpty {

            errorMessage = "Please fill all fields"
            return false
        }

        if !mail.contains("@") || !mail.contains(".") {

            errorMessage = "Enter a valid email address"
            return false
        }

        if password.count < 6 {

            errorMessage = "Password must contain at least 6 characters"
            return false
        }

        if password != confirmPassword {

            errorMessage = "Passwords do not match"
            return false
        }

        let userKey = user.lowercased()

        var allUsers = users

        if allUsers[userKey] != nil {

            errorMessage = "Username already exists"
            return false
        }

        allUsers[userKey] = [
            "username": user,
            "fullName": name,
            "email": mail,
            "passwordHash": hashPassword(password)
        ]

        users = allUsers

        fullName = ""
        email = ""
        username = ""
        password = ""
        confirmPassword = ""

        errorMessage = ""

        return true
    }

    // MARK: - Login

    func login() {

        let user = username.trimmingCharacters(
            in: .whitespaces
        )

        let userKey = user.lowercased()

        if user.isEmpty || password.isEmpty {

            errorMessage = "Please enter username and password"
            return
        }

        let allUsers = users

        if let account = allUsers[userKey],
           let savedHash = account["passwordHash"] {

            if hashPassword(password) == savedHash {

                currentUsername = userKey

                defaults.set(
                    userKey,
                    forKey: "lastAuthenticatedUsername"
                )

                isAuthenticated = true
                errorMessage = ""
                password = ""

                return
            }
        }

        // Support old demo account

        let oldUsername = defaults.string(
            forKey: "savedUsername"
        ) ?? "admin"

        let oldPassword = defaults.string(
            forKey: "savedPassword"
        ) ?? "1234"

        let oldHash = defaults.string(
            forKey: "savedPasswordHash"
        )

        let passwordMatches: Bool

        if let oldHash = oldHash {

            passwordMatches = hashPassword(password) == oldHash

        } else {

            passwordMatches = password == oldPassword
        }

        if user.caseInsensitiveCompare(oldUsername) == .orderedSame
            && passwordMatches {

            currentUsername = userKey

            defaults.set(
                userKey,
                forKey: "lastAuthenticatedUsername"
            )

            isAuthenticated = true
            errorMessage = ""
            password = ""

        } else {

            isAuthenticated = false
            errorMessage = "Invalid username or password"
        }
    }

    // MARK: - Face ID Authentication

    func authenticateWithFaceID() {

        guard let savedUser = defaults.string(
            forKey: "lastAuthenticatedUsername"
        ), !savedUser.isEmpty else {

            errorMessage = "Please login with username and password first."
            return
        }

        // Verify that the saved account still exists
        let allUsers = users

        let oldUsername = defaults.string(
            forKey: "savedUsername"
        ) ?? "admin"

        let isOldAccount = savedUser.caseInsensitiveCompare(
            oldUsername
        ) == .orderedSame

        guard allUsers[savedUser] != nil || isOldAccount else {

            errorMessage = "Account not found. Please login again."
            return
        }

        BiometricService.shared.authenticate {
            [weak self] success, message in

            guard let self = self else { return }

            if success {

                self.currentUsername = savedUser
                self.isAuthenticated = true
                self.errorMessage = ""

            } else {

                self.isAuthenticated = false
                self.errorMessage = message ??
                    "Face ID authentication failed"
            }
        }
    }

    // MARK: - Logout

    func logout() {

        isAuthenticated = false
        currentUsername = ""

        username = ""
        password = ""
        errorMessage = ""
    }
}
