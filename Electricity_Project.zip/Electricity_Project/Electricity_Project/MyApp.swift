
import SwiftUI

@main
struct Electricity_ProjectApp: App {

    var body: some Scene {

        WindowGroup {

            RootView()
        }
    }
}
