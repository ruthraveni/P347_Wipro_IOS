import Foundation

struct User: Identifiable, Codable {

    var id: UUID = UUID()

    var username: String
    var password: String
    var fullName: String

}

