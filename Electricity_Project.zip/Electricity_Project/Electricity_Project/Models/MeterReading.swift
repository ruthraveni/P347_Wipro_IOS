import Foundation

struct MeterReading: Identifiable, Codable {

    var id: UUID = UUID()

    var readingDate: Date
    var currentReading: Double
    var previousReading: Double

    var meterName: String
    var ratePerUnit: Double
    var notes: String

    // Calculate consumed electricity units
    var unitsConsumed: Double {
        currentReading - previousReading
    }

    // Calculate estimated electricity bill
    var estimatedCost: Double {
        unitsConsumed * ratePerUnit
    }
}
