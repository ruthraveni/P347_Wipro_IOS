
import Foundation

class StorageService {

    static let shared = StorageService()

    private let oldStorageKey = "ElectricityMeterReadings"

    private init() {}

    private func storageKey(for username: String) -> String {
        let safeUsername = username
            .trimmingCharacters(in: .whitespaces)
            .lowercased()

        return "ElectricityMeterReadings_\(safeUsername)"
    }


    func saveReadings(_ readings: [MeterReading], for username: String) {

        guard !username.isEmpty else { return }

        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(readings)

            UserDefaults.standard.set(
                data,
                forKey: storageKey(for: username)
            )

            print("Saved \(readings.count) readings for \(username)")

        } catch {
            print("SAVE ERROR: \(error.localizedDescription)")
        }
    }


    func loadReadings(for username: String) -> [MeterReading] {

        guard !username.isEmpty else {
            return []
        }

        let key = storageKey(for: username)

        if let data = UserDefaults.standard.data(forKey: key) {
            return decodeReadings(data)
        }

       
        let oldUsername = UserDefaults.standard.string(
            forKey: "savedUsername"
        ) ?? "admin"

        if username.caseInsensitiveCompare(oldUsername) == .orderedSame,
           let oldData = UserDefaults.standard.data(forKey: oldStorageKey) {

            UserDefaults.standard.set(oldData, forKey: key)

            print("Old readings migrated for \(username)")

            return decodeReadings(oldData)
        }

        print("No readings found for \(username)")
        return []
    }

    private func decodeReadings(_ data: Data) -> [MeterReading] {

        do {
            return try JSONDecoder().decode(
                [MeterReading].self,
                from: data
            )
        } catch {
            print("LOAD ERROR: \(error.localizedDescription)")
            return []
        }
    }

    func deleteAllReadings(for username: String) {

        guard !username.isEmpty else { return }

        UserDefaults.standard.removeObject(
            forKey: storageKey(for: username)
        )

        print("Deleted readings for \(username)")
    }
}
