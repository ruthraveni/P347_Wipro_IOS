
import Foundation
import LocalAuthentication

class BiometricService {

    static let shared = BiometricService()

    private init() {}

    func authenticate(completion: @escaping (Bool, String?) -> Void) {

        let context = LAContext()
        context.localizedCancelTitle = "Use Password"

        var error: NSError?

        guard context.canEvaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            error: &error
        ) else {
            DispatchQueue.main.async {
                completion(false, "Face ID is not available. Use password login.")
            }
            return
        }

        context.evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: "Login to Electricity Meter Log"
        ) { success, authError in

            DispatchQueue.main.async {

                if success {
                    completion(true, nil)
                } else {
                    completion(
                        false,
                        authError?.localizedDescription ?? "Face ID failed"
                    )
                }
            }
        }
    }
}
